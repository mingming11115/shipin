# WorkBuddy Skills 云备份恢复指南（2026-11-21）

## 同步内容
- presentation-script/   → 拷到新电脑 C:/Users/<用户名>/.workbuddy/skills/ 下
- remotion-video-maker/  → 同上
- package.json / tsconfig.json / remotion.config.ts → Remotion 工程配置（放回 shipin/07_remotion/）

## 恢复步骤（新电脑）
1. 把对应文件夹放到 ~/.workbuddy/skills/（即 C:/Users/<用户名>/.workbuddy/skills/），重启 WorkBuddy
2. Remotion 工程：npm install --registry=https://registry.npmmirror.com（在 07_remotion/ 内）
3. Python 包：python -m pip install -i https://mirrors.aliyun.com/pypi/simple edge-tts imageio-ffmpeg pymupdf
4. figgenie-paper-diagram（544MB，未随包同步）：从 https://github.com/Sleepy-Avacado/FigGenie-paper-diagram-skill 重新下载安装
