#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
timing_check.py —— 讲稿控时核对

用法:
    python timing_check.py --script 讲稿.md --minutes 5
    python timing_check.py --script 讲稿.md --minutes 3 --pace 260
    python timing_check.py --script 讲稿.md --minutes 10 --json
    python timing_check.py --selftest

做什么:
    1. 剥掉不念出声的部分（[...] 表达提示、Markdown 记号、表格竖线、代码块）
    2. 统计净口播字数（中文字符 + 数字字符 + 英文单词 x 1.5）
    3. 按 220-260 字/分钟估算时长，与目标时长比误差，阈值 15%

为什么要有这个脚本:
    手写讲稿最容易失控的就是字数。「3 分钟版写了 2000 字」是真实的失败模式——
    那是 8 分钟的量。字数可以靠眼睛估，但眼睛估不准，脚本一秒算完。

退出码:
    0 = PASS（误差 < 15%）
    1 = FAIL（需增删字数，报告里给出具体字数）
    2 = 参数错误
"""
import argparse
import json
import os
import re
import sys

PACE_MIN = 220
PACE_MAX = 260
PACE_DEFAULT = 240
TOLERANCE = 0.15

CJK_RANGE = "\u4e00-\u9fff\u3400-\u4dbf\uf900-\ufaff"
RE_MARK = re.compile(r"\[[^\]]*\]")          # [停顿] [重点强调] 之类的表达提示
RE_FENCE = re.compile(r"```.*?```", re.S)    # 代码块
RE_INLINE_CODE = re.compile(r"`[^`]*`")
RE_HEADING = re.compile(r"(?m)^\s*#{1,6}\s*")
# 元信息行：整行剥掉。「> 听众：…」这种是要看的不是要念的，
# 别用它放口播内容（与 number_audit.py 的 RE_META_LINE 保持一致）
RE_QUOTE = re.compile(r"(?m)^\s*>.*$")
RE_BULLET = re.compile(r"(?m)^\s*[-*+]\s+")
# 后跟数字的是小数（「4.2 万里」行首），不是列表序号 —— 加了 (?!\d) 防误剥
RE_ORDERED = re.compile(r"(?m)^\s*\d+[\.、)](?!\d)\s*")
RE_BOLD = re.compile(r"\*\*|\*|__")
RE_PIPE = re.compile(r"(?m)^\s*\|")
RE_TABLE_SEP = re.compile(r"(?m)^\s*\|?[\s:\-\|]+\|[\s:\-\|]*$")
RE_HR = re.compile(r"(?m)^\s*[-=]{3,}\s*$")
RE_PUNCT_STRIP = re.compile(r"[|`>#*]")

RE_CJK = re.compile(r"[" + CJK_RANGE + r"]")
RE_DIGIT = re.compile(r"\d")
RE_ENWORD = re.compile(r"[A-Za-z]+")

# 出现这类标题后，后面的内容是要看的、不是要念的，默认不计入时长
RE_STOP = re.compile(r"追问|摘要|附录|备用|Q\s*&\s*A|问答|一页纸")

# 分段标题：Markdown 标题 / 「第 N 页」（见 split_segments）


def strip_marks(text):
    """剥掉不念出声的记号与标注，只留会被念出来的文字。"""
    text = RE_FENCE.sub("", text)
    text = RE_INLINE_CODE.sub("", text)
    text = RE_MARK.sub("", text)           # [停顿] 等表达提示
    text = RE_TABLE_SEP.sub("", text)
    text = RE_HR.sub("", text)
    text = RE_HEADING.sub("", text)
    text = RE_QUOTE.sub("", text)
    text = RE_BULLET.sub("", text)
    text = RE_ORDERED.sub("", text)
    text = RE_BOLD.sub("", text)
    text = RE_PIPE.sub("", text)
    text = RE_PUNCT_STRIP.sub("", text)
    return text


def count_words(text):
    """返回 (中文字数, 数字字符数, 英文单词数, 折算总字数)。"""
    cjk = len(RE_CJK.findall(text))
    digit = len(RE_DIGIT.findall(text))
    en = len(RE_ENWORD.findall(text))
    total = cjk + digit + int(en * 1.5 + 0.5)
    return cjk, digit, en, total


HEADING_PAT = re.compile(r"^\s*(?:#{1,6}\s*)?[*_]{0,2}\s*(.+?)\s*[*_]{0,2}\s*$")
PAGE_HEADING_PAT = re.compile(r"^\s*(?:#{1,6}\s*)?[*_]{0,2}\s*(第\s*\d+\s*页[^\n]*?)\s*[*_]{0,2}\s*$")


def split_segments(text):
    """按 Markdown 标题 / 「第 N 页」/ 「【xxx】」切成段，返回 [(段名, 段正文)]。"""
    lines = text.split("\n")
    segs = []
    cur_name = "开场"
    cur = []
    for line in lines:
        m = (PAGE_HEADING_PAT.match(line) or HEADING_PAT.match(line)
             if _is_heading(line) else None)
        if m:
            if cur:
                segs.append((cur_name, "\n".join(cur)))
            cur_name = m.group(1).strip()
            cur = []
        else:
            cur.append(line)
    if cur:
        segs.append((cur_name, "\n".join(cur)))
    return [(n, t) for n, t in segs if strip_marks(t).strip()]


def _is_heading(line):
    """判断一行是不是标题：`# xxx` / `## xxx` / `【xxx】` / `第 N 页…` 单独成行。"""
    s = line.strip()
    if not s:
        return False
    if s.startswith("#"):
        return True
    if re.match(r"^【.+】\s*$", s):
        return True
    if re.match(r"^[*_]{0,2}\s*第\s*\d+\s*页", s):
        return True
    return False


def analyze(text, minutes, pace=PACE_DEFAULT, count_all=False):
    """统计净口播字数并核对时长。

    默认只统计「会被念出来」的部分：从开场到收尾为止。
    出现「追问 / 摘要 / 附录 / 备用」一类标题后，后面的内容不计入——
    那是要看的东西，不是要念的东西。（用 --count-all 可关掉这个切分）
    """
    segs = split_segments(text)
    spoken, skipped = segs, []
    if segs and not count_all:
        spoken, skipped = [], []
        stopped = False
        for name, body in segs:
            if RE_STOP.search(name):
                stopped = True
            (skipped if stopped else spoken).append((name, body))

    if spoken:
        spoken_text = "\n".join(b for _, b in spoken)
        cjk, digit, en, total = count_words(strip_marks(spoken_text))
    else:
        cjk, digit, en, total = count_words(strip_marks(text))
    est = total / float(pace)
    slow = total / float(PACE_MAX)   # 念得慢 -> 时间更长
    fast = total / float(PACE_MIN)   # 念得快 -> 时间更短
    err = (est - minutes) / float(minutes)
    need = int(round(minutes * pace)) - total
    segs_out = []
    for name, body in spoken:
        _, _, _, st = count_words(strip_marks(body))
        segs_out.append({
            "name": name,
            "words": st,
            "minutes": round(st / float(pace), 2),
            "seconds": int(round(st / float(pace) * 60)),
        })
    return {
        "target_minutes": minutes,
        "pace": pace,
        "cjk": cjk,
        "digit": digit,
        "en_words": en,
        "total": total,
        "est_minutes": round(est, 2),
        "range_minutes": [round(slow, 2), round(fast, 2)],
        "error_pct": round(err * 100, 1),
        "pass": abs(err) < TOLERANCE,
        "delta_words": need,          # 正数=还可补这么多字, 负数=需删这么多字
        "target_words": int(round(minutes * pace)),
        "segments": segs_out,
        "skipped_sections": [n for n, _ in skipped],
    }


def render(res):
    out = []
    out.append("目标时长 %s 分钟 | 语速 %d 字/分（区间 %d-%d）" %
               (res["target_minutes"], res["pace"], PACE_MIN, PACE_MAX))
    out.append("净口播字数：%d 字（中文 %d / 数字 %d / 英文 %d 词≈%d）" %
               (res["total"], res["cjk"], res["digit"], res["en_words"],
                int(res["en_words"] * 1.5 + 0.5)))
    out.append("目标字数：%d 字（%d 分钟 x %d 字/分）" %
               (res["target_words"], res["target_minutes"], res["pace"]))
    out.append("估算时长：%.2f 分钟（念慢 %.2f / 念快 %.2f）" %
               (res["est_minutes"], res["range_minutes"][0], res["range_minutes"][1]))
    out.append("误差：%+.1f%%  %s（阈值 ±%d%%）" %
               (res["error_pct"], "PASS" if res["pass"] else "FAIL", int(TOLERANCE * 100)))
    if res["delta_words"] > 0:
        out.append("→ 还可补 %d 字（约 %d 秒）" %
                   (res["delta_words"], int(round(res["delta_words"] / float(res["pace"]) * 60))))
    elif res["delta_words"] < 0:
        out.append("→ 需删 %d 字（约 %d 秒）。优先砍最不重要的整段，不要每句都削一点。" %
                   (-res["delta_words"], int(round(-res["delta_words"] / float(res["pace"]) * 60))))
    if res["segments"]:
        out.append("")
        out.append("分段字数：")
        for s in res["segments"]:
            out.append("  %-28s %5d 字  ~%d 秒" % (s["name"][:28], s["words"], s["seconds"]))
    if res.get("skipped_sections"):
        out.append("不计入（非口播部分）：%s" % "、".join(res["skipped_sections"]))
    return "\n".join(out)


def _selftest():
    ok = True

    def chk(name, cond, extra=""):
        nonlocal ok
        print(("  PASS  " if cond else "  FAIL  ") + name + (" " + extra if extra and not cond else ""))
        if not cond:
            ok = False

    chk("中文计数", count_words("你好世界")[3] == 4)
    chk("表达提示不计数", count_words(strip_marks("你好[停顿][重点强调]世界"))[3] == 4)
    chk("Markdown 记号不计数(粗体)", count_words(strip_marks("**加粗**"))[3] == 2)
    chk("Markdown 记号不计数(表格竖线)", count_words(strip_marks("|管道|"))[3] == 2)
    chk("Markdown 记号不计数(标题井号)", count_words(strip_marks("## 标题"))[3] == 2)
    chk("数字按字符计", count_words(strip_marks("达成 112%"))[3] == 5, str(count_words(strip_marks("达成 112%"))))

    r = analyze("字" * 720, 3)
    chk("720 字 / 3 分钟 PASS", r["pass"] and abs(r["error_pct"]) < 1, str(r["error_pct"]))
    r = analyze("字" * 2000, 3)
    chk("2000 字 / 3 分钟 FAIL", (not r["pass"]) and r["delta_words"] < 0)
    chk("2000 字需删 1280", r["delta_words"] == 720 - 2000, str(r["delta_words"]))

    txt = "# 开场\n你好世界\n## 第 2 页\n重点来了\n"
    segs = split_segments(txt)
    chk("按标题分段", len(segs) == 2 and segs[0][0] == "开场", str([s[0] for s in segs]))

    segs = split_segments("【开场】\n你好\n【第 2 页｜数据】\n重点\n")
    chk("【】与第N页也能分段", len(segs) == 2, str([s[0] for s in segs]))

    # 行首小数不能被当成列表序号（否则「4.2 万」会变成「2 万」）
    chk("行首小数不被误剥",
        count_words(strip_marks("新增用户 4.2 万，六成来自渠道 B。"))[0] >= 10,
        str(count_words(strip_marks("新增用户 4.2 万，六成来自渠道 B。"))))

    r = analyze("字" * 2400, 10)
    chk("2400 字 / 10 分钟 PASS", r["pass"])

    # 追问与摘要是不念的部分，默认不计入
    doc = "# 开场\n" + "字" * 700 + "\n## 听众可能追问\n" + "字" * 500 + "\n## 一页纸摘要\n" + "字" * 300
    r = analyze(doc, 3)
    chk("追问与摘要不计入", r["total"] == 700 and r["skipped_sections"], str(r["total"]))
    r2 = analyze(doc, 3, count_all=True)
    chk("--count-all 会计入", r2["total"] == 1500, str(r2["total"]))

    # GBK 文件不能读成乱码（中文 Windows 常见）
    try:
        import tempfile
        fd, tmpp = tempfile.mkstemp(suffix=".md")
        os.close(fd)
        with open(tmpp, "wb") as f:
            f.write("## \u5f00\u573a\n[停顿] \u5148\u8bf4\u7ed3\u8bba\u3002\n".encode("gbk"))
        g = read_text(tmpp)
        chk("GBK 文件按 GB18030 解析", "\u5f00\u573a" in g and REPL not in g, repr(g[:20]))
        os.remove(tmpp)
    except Exception as e:                       # pragma: no cover
        chk("GBK 文件按 GB18030 解析", False, str(e))

    print("selftest: " + ("OK" if ok else "FAILED"))
    return 0 if ok else 1


REPL = "\ufffd"


def read_text(path):
    """读纯文本。UTF-8 解不出时回退 GB18030（中文 Windows 上很常见）。"""
    with open(path, "rb") as f:
        raw = f.read()
    for bom, enc in ((b"\xef\xbb\xbf", "utf-8-sig"),
                     (b"\xff\xfe", "utf-16"), (b"\xfe\xff", "utf-16")):
        if raw.startswith(bom):
            return raw.decode(enc, "replace")
    try:
        txt = raw.decode("utf-8")
        if REPL not in txt:
            return txt
    except UnicodeDecodeError:
        pass
    txt = raw.decode("gb18030", "replace")
    if REPL not in txt:
        print("提示：%s 不是 UTF-8，已按 GB18030 解析（建议另存为 UTF-8）"
              % os.path.basename(path))
        return txt
    return raw.decode("utf-8", "replace")


def main():
    ap = argparse.ArgumentParser(description="讲稿控时核对")
    ap.add_argument("--script", help="讲稿文件路径")
    ap.add_argument("--text", help="直接传入讲稿文本")
    ap.add_argument("--minutes", type=float, help="目标时长（分钟）")
    ap.add_argument("--pace", type=int, default=PACE_DEFAULT,
                    help="语速，默认 %d（中文口播常用 %d-%d）" % (PACE_DEFAULT, PACE_MIN, PACE_MAX))
    ap.add_argument("--count-all", action="store_true",
                    help="把追问/摘要等附录部分也计入（默认不计）")
    ap.add_argument("--json", action="store_true", help="输出 JSON")
    ap.add_argument("--selftest", action="store_true", help="跑内置自检")
    args = ap.parse_args()

    if args.selftest:
        return _selftest()

    if args.text:
        text = args.text
    elif args.script:
        if not os.path.exists(args.script):
            print("找不到讲稿文件: %s" % args.script)
            return 2
        text = read_text(args.script)
    else:
        print("需要 --script 或 --text")
        return 2

    if args.minutes is None:
        print("需要 --minutes（单位：分钟，例如 --minutes 5）")
        return 2
    if args.minutes <= 0:
        print("--minutes 必须大于 0")
        return 2
    if not (PACE_MIN <= args.pace <= PACE_MAX):
        print("语速应落在 %d-%d 字/分之间，当前 %d" % (PACE_MIN, PACE_MAX, args.pace))
        return 2

    res = analyze(text, args.minutes, args.pace, count_all=args.count_all)
    print(json.dumps(res, ensure_ascii=False, indent=2) if args.json else render(res))
    return 0 if res["pass"] else 1


if __name__ == "__main__":
    sys.exit(main())
