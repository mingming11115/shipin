#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
number_audit.py —— 讲稿数字溯源核对（防编造）

用法:
    python number_audit.py --script 讲稿.md --source 材料.md
    python number_audit.py --script 讲稿.md --source 材料1.md --source 材料2.md
    python number_audit.py --script 讲稿.md --source 材料.md --show-unused
    python number_audit.py --selftest

做什么:
    把讲稿里出现的每个数字，拿去原材料里找出处。找不到的列成「需人工确认」清单。

重要: 这是提醒，不是判定。
    「材料里没出现」不等于「编造」——可能是口算换算（112% → 多了六分之一）、
    可能是材料里写了「超额完成」没写数字、也可能是材料本身不全。所以脚本只列清单，
    由人确认。宁可多报一条让人看一眼，也不要把真编造的数字放过去。

豁免（这些数字不参与核对，另计）:
    [停顿3秒] 类表达提示、第 3 页 / P5 类页码、第 2 点类序数、行首序号、Q3 类期间标签、
    （3 条）类计数、交付头部 > 开头的元信息行、时长语境里的「5 分钟」、版本号。
    1900-2099 的年份单独归为「年份（低风险）」。

能读的材料格式:
    .md / .txt（含 GBK / GB2312，自动回退 GB18030）
    .docx / .pptx（零依赖直读：slide 正文、备注页、图表数值都会取）
    读不了 .doc / .ppt（老二进制格式）与 .pdf —— 会提示先另存或导出，不硬猜。

退出码:
    0 = 所有数字都能在材料里找到出处
    1 = 存在需人工确认的数字（清单已打印）
    2 = 参数错误
"""
import argparse
import os
import re
import sys
import xml.etree.ElementTree as ET
import zipfile

UNIT = (r"%|％|个百分点|倍|万|亿|千|元|块|人|天|小时|分钟|秒|次|个|条|项|页|版|"
        r"年|月|日|度|分|台|家|笔|轮")
# 千分位只吃「逗号 + 恰好 3 位数字」（1,234）。早期写法 \d[\d,]* 会把
# 尾随逗号一起吃进 token（「QPS 8600，其中」取出 '8600,'），报告里显示不干净；
# 更麻烦的是逗号两侧都是数字时会合成一个数（「18，31」→ 1831），静默算错。
RE_NUM = re.compile(r"\d+(?:,\d{3})*(?:\.\d+)?\s*(?:" + UNIT + r")?")

RE_FENCE = re.compile(r"```.*?```", re.S)
RE_MARK = re.compile(r"\[[^\]]*\]")
# Markdown 强调记号。不清掉的话，加粗的编号列表（「**1. 听众会问：**」）
# 不满足「行首序号」规则，会把 1 / 2 / 3 当成三个无出处的数字报出来——
# 而追问预备里正是这么编号的，等于人人中招。
RE_BOLD = re.compile(r"\*\*|__")
# 页码。英文分支要求 P 前面不是字母，否则「Top 200」「Step 3」「Group 2」
# 会被当成 P200 / P3 / P2 吃掉——数字凭空从材料里消失，讲稿引用它时
# 永远报「找不到出处」。空白限定成 [ \t]，避免 \s 跨行吃到下一行的内容。
RE_PAGE = re.compile(r"第[ \t]*\d+[ \t]*页|(?<![A-Za-z])[Pp]\.?[ \t]*\d+(?![.\d])")
# 「第 N 个/点/步…」是序数，不是数据。必须带「第」前缀，否则会把
# 「新增 5 个客户」这类真数据一起豁免掉（那才是护栏要盯的）。
# 「段/单元」是交付模板里给表达单元编号用的（第 1 段、第 2 段），
# 漏了它会让段号变成「需人工确认」——材料里数字一少就满屏噪音。
RE_ORDINAL = re.compile(r"第\s*\d+\s*(?:点|部分|节|章|步|条|版|段|单元|阶段|档|个|位|名|次|批|轮|组|类|项)")
RE_LISTNO = re.compile(r"(?m)^\s*\d+[\.、)](?!\d)\s*")   # 后跟数字的是小数，不是序号
RE_QUARTER = re.compile(r"[Qq]\d\b")                     # Q3 / Q2 是期间标签，不是数据
RE_PAREN_NO = re.compile(r"[(（]\s*\d+\s*(?:条|项|个|点|问)\s*[)）]")  # 「（3 条）」类计数
RE_META_LINE = re.compile(r"(?m)^\s*>.*$")               # 交付头部元信息行（时长/字数/听众）
# 口语里的「3 秒」「5 分钟」基本都是流程时长，不是业务数据，一律豁免。
# 代价：以分钟为单位的业务指标会被放过，所以报告末尾会提醒一句。
RE_DURATION = re.compile(r"\d+\s*(?:秒钟?|分钟)")
# 段标题里的字数预算「（约 130 字 / 32 秒）」是给讲的人看的提示，不是数据。
# SKILL.md 的交付模板自带这个写法，不豁免的话每个用户都会收到一条纯噪音。
RE_BUDGET = re.compile(r"约?\s*\d+\s*字\s*(?:/\s*\d+\s*秒)?|约\s*\d+\s*字")
RE_VERSION = re.compile(r"[vV]\d+(?:\.\d+)+")
RE_TABLE_SEP = re.compile(r"(?m)^[ \t]*\|?[ \t:\-\|]+\|[ \t:\-\|]*$")
RE_YEAR = re.compile(r"^(?:19|20)\d{2}\s*年?$")

# 中文数字与阿拉伯数字混用是中文材料的常态：材料写「一个正式编制」，
# 讲稿写「1 个正式编制」，说的是同一件事。不归一化的话每次都会多出一条
# 「需人工确认」——而误报多了使用者就开始无视这份清单，那比漏一条更糟。
# 只在**材料侧**展开，且只认「单个中文数字 + 计数单位」（一个 / 三条 / 两家）。
# 不碰「十」「十二」「二十」这类复合数词：算错复合数词会反过来掩盖真编造。
CN_NUM = {"一": 1, "两": 2, "二": 2, "三": 3, "四": 4,
          "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}
# UNIT 本身是 (?:...) 非捕获组，这里必须再包一层捕获括号，
# 否则 findall 只返回中文数字一个元素，解包直接抛 ValueError。
RE_CN_NUM = re.compile("([" + "".join(CN_NUM) + r"])\s*(" + UNIT + r")")

# 只映射全角数字与全角标点。注意不要把全角空格（U+3000）放进来——
# 它减 0xFEE0 会是负数，translate 直接抛 ValueError。
FULL2HALF = {ord(c): ord(c) - 0xFEE0 for c in "０１２３４５６７８９．，"}

# .docx / .pptx 本质是 zip + XML，标准库就能读出文字（见 read_ooxml）。
# 真实用户手里是 deck 不是 md，让他「先导出成 txt」等于把活推回给他。
OOXML_EXT = (".docx", ".pptx")
# 这三种读不出纯文本：.doc/.ppt 是 Office 97-2003 二进制格式，
# PDF 的文本流需要专门解析库（long-doc-reader 同样要求 pypdf/pdfplumber 一类）。
# 与其猜出一个满屏乱的文本、再让数字核对全盘误报，不如直接说清楚。
UNREADABLE_EXT = (".doc", ".ppt", ".pdf", ".xlsx", ".xls", ".wps")

MAX_LIST = 30   # 报告最多列多少类；超了折叠，避免刷屏

REPL = "\ufffd"


def read_text(path):
    """读纯文本。UTF-8 解不出时回退 GB18030（中文 Windows 上很常见）。"""
    with open(path, "rb") as f:
        raw = f.read()
    for bom, enc in ((b"\xef\xbb\xbf", "utf-8-sig"),
                     (b"\xff\xfe", "utf-16"), (b"\xfe\xff", "utf-16")):
        if raw.startswith(bom):
            return raw.decode(enc, "replace")
    try:
        txt = raw.decode("utf-8")
        if REPL not in txt:
            return txt
    except UnicodeDecodeError:
        pass
    txt = raw.decode("gb18030", "replace")
    if REPL not in txt:
        print("提示：%s 不是 UTF-8，已按 GB18030 解析（建议另存为 UTF-8）"
              % os.path.basename(path))
        return txt
    return raw.decode("utf-8", "replace")


# ------------------------------------------------------------ OOXML 直读
# .docx / .pptx 是 zip + XML，标准库就能读。真实用户手里是 deck 不是 md。
A_NS = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
C_NS = "{http://schemas.openxmlformats.org/drawingml/2006/chart}"
W_NS = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"

RE_SLIDE = re.compile(r"^ppt/slides/slide(\d+)\.xml$")
RE_NOTES = re.compile(r"^ppt/notesSlides/notesSlide(\d+)\.xml$")
RE_CHART = re.compile(r"^ppt/(?:slides/)?charts/chart(\d+)\.xml$")


def _runs_text(node, tag):
    """把一个段落里所有 run 的文本拼起来。

    必须按段落拼、不能逐 run 成行：真 deck 里「Q3 增长复盘」常常被拆成
    「Q3 」「增长复盘」两个 <a:t>，逐 run 取会得到一堆碎片。
    """
    return "".join(t.text or "" for t in node.iter(tag))


def _xml_root(xml):
    try:
        return ET.fromstring(xml)
    except ET.ParseError:
        return None


def _drawing_lines(xml):
    """slide / 图表 XML -> 文本行。"""
    root = _xml_root(xml)
    if root is None:
        return []
    lines = []
    for p in root.iter(A_NS + "p"):
        t = _runs_text(p, A_NS + "t").strip()
        if t:
            lines.append(t)
    for v in root.iter(C_NS + "v"):       # 图表缓存数值，正文里查不到
        t = (v.text or "").strip()
        if t:
            lines.append(t)
    return lines


def _word_lines(xml):
    """word/document.xml -> 文本行（表格单元格也会各自成行）。"""
    root = _xml_root(xml)
    if root is None:
        return []
    return [t for t in (_runs_text(p, W_NS + "t").strip()
                        for p in root.iter(W_NS + "p")) if t]


def read_ooxml(path):
    """读 .docx / .pptx 的纯文本。零依赖（zipfile + ElementTree）。

    .pptx 的取法：按页码顺序读 slide；备注页与图表一并取——
    图表里的数值（<c:v>）往往不在任何文本里，漏掉它们会让讲稿引用的
    图上数字全部变成「找不到出处」。
    """
    if not zipfile.is_zipfile(path):
        raise ValueError("打不开：不是有效的 .docx / .pptx（若为 .doc/.ppt 老格式，请先另存为新格式）")
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        out = []
        if "word/document.xml" in set(names):
            out += _word_lines(z.read("word/document.xml"))

        def ordered(pat):
            got = [n for n in names if pat.match(n)]
            return sorted(got, key=lambda n: int(pat.match(n).group(1)))

        for n in ordered(RE_SLIDE):
            body = _drawing_lines(z.read(n))
            if body:
                out.append("【第 %s 页】" % RE_SLIDE.match(n).group(1))
                out += body
        for n in ordered(RE_NOTES):        # 备注页：讲的人自己写的提示，常含真数据
            out += _drawing_lines(z.read(n))
        for n in ordered(RE_CHART):
            out += _drawing_lines(z.read(n))
    if not out:
        raise ValueError("这个文件里读不到文字（可能是纯图片的 deck）")
    return "\n".join(out)


def read_any(path):
    """按扩展名选读法：纯文本（带编码回退）/ OOXML 直读。"""
    if path.lower().endswith(OOXML_EXT):
        return read_ooxml(path)
    return read_text(path)


def normalize(text):
    text = text.translate(FULL2HALF)
    return text

def strip_exempt(text):
    """剥掉不该参与核对的数字（页码/序号/标注/时长），返回 (处理后文本, 豁免计数)。"""
    before = len(RE_NUM.findall(text))
    text = RE_FENCE.sub("", text)
    text = RE_MARK.sub("", text)
    text = RE_BOLD.sub("", text)
    text = RE_PAGE.sub("", text)
    text = RE_ORDINAL.sub("", text)
    text = RE_LISTNO.sub("", text)
    text = RE_QUARTER.sub("", text)
    text = RE_PAREN_NO.sub("", text)
    text = RE_META_LINE.sub("", text)
    text = RE_DURATION.sub("", text)
    text = RE_BUDGET.sub("", text)
    text = RE_VERSION.sub("", text)
    text = RE_TABLE_SEP.sub("", text)
    after = len(RE_NUM.findall(text))
    return text, max(0, before - after)


def parse_token(tok):
    """解析数字 token，返回 (原文, 精确值集合, 倍率换算值集合, 是否年份)。

    倍率换算（112% <-> 1.12 倍）只对**显式带 % 或「倍」**的数字开放。
    早期版本对每个数字都生成 {v, v/100, v*100}，结果是讲稿里编个「增长 100%」
    只要材料里出现过任何一个「1」就被放行——那是漏检，比误报危险得多。
    """
    raw = tok.strip()
    if RE_YEAR.match(raw):
        return raw, set(), set(), True
    m = re.match(r"^([\d,]+(?:\.\d+)?)\s*(.*)$", raw)
    if not m:
        return raw, set(), set(), False
    num = m.group(1).replace(",", "").rstrip(".")
    unit = m.group(2)
    try:
        v = float(num)
    except ValueError:
        return raw, set(), set(), False
    mult = 1.0
    if unit.endswith("亿"):
        mult = 1e8
    elif unit.endswith("万"):
        mult = 1e4
    elif unit.endswith("千"):
        mult = 1e3
    base = v * mult
    exact = {round(base, 6)}
    ratio = set()
    if unit.lstrip().startswith("%"):
        ratio.add(round(base / 100.0, 6))
    elif "倍" in unit:
        ratio.add(round(base * 100.0, 6))
    return raw, exact, ratio, False


def extract(text, expand_cn=False):
    """返回 (token 列表, 豁免个数)。

    expand_cn=True 时额外补出「一个 -> 1个」这类阿拉伯形式，供材料侧使用。
    讲稿侧不开：讲稿写「一个」本来就不产生数字 token，不会被核对，
    展开它只会让报告里多出一堆合成的 token。
    """
    text = normalize(text)
    text, exempted = strip_exempt(text)
    toks = [t.strip() for t in RE_NUM.findall(text)]
    if expand_cn:
        toks += ["%d%s" % (CN_NUM[c], u) for c, u in RE_CN_NUM.findall(text)]
    return toks, exempted


def audit(script_text, source_text):
    s_toks, s_exempt = extract(script_text)
    src_toks, _ = extract(source_text, expand_cn=True)

    src_exact = set()        # 材料里所有数字的精确值
    src_ratio_ctx = set()    # 材料里「带 % 或倍」的数字，其精确值可与倍率换算互通
    for t in src_toks:
        _, e, r, _ = parse_token(t)
        src_exact |= e
        if r:
            src_ratio_ctx |= e

    traced, untraced, years = [], [], []
    for t in s_toks:
        raw, e, r, is_year = parse_token(t)
        if is_year:
            years.append(raw)
            continue
        hit = bool(e & src_exact) or bool(r & src_ratio_ctx)
        if not e:
            traced.append(raw)   # 解析不出数值的，交给人看，不算疑似
        elif hit:
            traced.append(raw)
        else:
            untraced.append(raw)

    def tally(items):
        d = {}
        for i in items:
            d[i] = d.get(i, 0) + 1
        return sorted(d.items(), key=lambda kv: (-kv[1], kv[0]))

    used = set()
    for t in s_toks:
        _, e, r, _ = parse_token(t)
        used |= e | r
    unused = []
    seen = set()
    for t in src_toks:
        raw, e, _, _ = parse_token(t)
        if raw in seen:
            continue
        seen.add(raw)
        if e and not (e & used):
            unused.append(raw)

    return {
        "script_tokens": len(s_toks),
        "source_tokens": len(src_toks),
        "exempted": s_exempt,
        "traced": tally(traced),
        "untraced": tally(untraced),
        "years": tally(years),
        "unused_from_source": sorted(set(unused)),
    }


def render(res, show_unused=False):
    out = []
    out.append("讲稿数字 %d 个 | 材料数字 %d 个 | 已豁免结构计数 %d 个" %
               (res["script_tokens"], res["source_tokens"], res["exempted"]))
    out.append("")
    out.append("有出处（%d 类）：%s" %
               (len(res["traced"]),
                "、".join("%s(x%d)" % (k, v) for k, v in res["traced"]) or "无"))
    if res["years"]:
        out.append("年份（低风险，通常无需溯源）：%s" %
                   "、".join("%s(x%d)" % (k, v) for k, v in res["years"]))
    out.append("")
    if res["untraced"]:
        out.append("需人工确认（材料中未找到，%d 类）：" % len(res["untraced"]))
        for k, v in res["untraced"][:MAX_LIST]:
            out.append("   - %s (x%d)" % (k, v))
        if len(res["untraced"]) > MAX_LIST:
            out.append("   - ……另有 %d 类未列出" % (len(res["untraced"]) - MAX_LIST))
        out.append("")
        out.append("逐条处理：能换算的补一句出处；换不出来的，要么删掉，要么改成定性说法。")
        out.append("注意：这是提醒不是判定 —— 口算换算与材料缺失都会出现在这里。")
    else:
        out.append("需人工确认：无")
    out.append("已豁免：页码 / 序号 / 期间标签（Q3）/ 表达标注 / 元信息行 / 时长类数字。"
               "若讲稿里有以分钟为单位的业务指标，豁免会放过它，那种请单独看一眼。")
    if show_unused and res["unused_from_source"]:
        out.append("")
        out.append("材料里有但讲稿没用（仅供参考，短版本本来就该砍）：%s" %
                   "、".join(res["unused_from_source"][:30]))
    return "\n".join(out)


def _selftest():
    ok = True

    def chk(name, cond, extra=""):
        nonlocal ok
        print(("  PASS  " if cond else "  FAIL  ") + name + (" " + extra if extra and not cond else ""))
        if not cond:
            ok = False

    # 1. 有出处
    r = audit("我们达成了 112%。", "Q3 达成率 112%，超出目标。")
    chk("相同数字有出处", not r["untraced"] and r["traced"], str(r))

    # 2. 百分比 / 倍数换算算有出处
    r = audit("转化是原来的 1.12 倍。", "转化率 112%")
    chk("112% 与 1.12 倍互通", not r["untraced"], str(r["untraced"]))

    # 3. 无出处要报
    r = audit("留存从 87% 掉了 15 个点。", "留存 62%。")
    chk("编造数字被报出", len(r["untraced"]) == 2, str(r["untraced"]))

    # 4. 豁免：页码 / 标注 / 序号 / 时长
    r = audit("第 3 页[停顿3秒]1. 开场，给大家 5 分钟。", "给大家 5 分钟。")
    chk("页码与标注被豁免", not r["untraced"], str(r["untraced"]))

    # 5. 年份单独归类
    r = audit("2026 年我们做到 112%。", "112%，2026 年。")
    chk("年份归为低风险", r["years"] and not r["untraced"], str(r))

    # 6. 万 / 亿换算
    r = audit("成本 1.2 亿。", "成本 120000000 元")
    chk("亿换算互通", not r["untraced"], str(r["untraced"]))

    # 7. 全角数字
    r = audit("达成 １１２％", "达成 112%")
    chk("全角数字归一化", not r["untraced"], str(r["untraced"]))

    # 8. 行首小数不能被当成列表序号（"4.2 万" 行首）
    r = audit("新增用户 4.2 万，六成来自渠道 B。", "新增 4.2 万")
    chk("行首小数不被误伤", not r["untraced"], str(r["untraced"]))

    # 9. 计数括号与元信息行豁免
    r = audit("## 听众可能追问（3 条）\n他问 Q3 的 112%。", "112%")
    chk("括号计数与期间标签豁免", not r["untraced"], str(r["untraced"]))
    r = audit("> 时长 3 分钟　目标字数 720　语速 240\n达成 112%。", "112%")
    chk("元信息行豁免", not r["untraced"], str(r["untraced"]))

    # 10. 多份材料合并后也能溯源（数字分散在不同文件里）
    r = audit("达成 112%，新增 4.2 万。", "达成率 112%")
    chk("单份材料缺数字仍会报", len(r["untraced"]) == 1, str(r["untraced"]))
    r = audit("达成 112%，新增 4.2 万。", "达成率 112%\n新增用户 4.2 万")
    chk("合并多份材料后有出处", not r["untraced"], str(r["untraced"]))

    # 11. 序数豁免要带「第」：第 5 个要点豁免，新增 5 个客户不能豁免
    r = audit("第 5 个要点是新增 5 个客户。", "要点清单")
    chk("第N个序数豁免", [k for k, _ in r["untraced"]] == ["5 个"], str(r["untraced"]))
    r = audit("第 5 个要点是新增 5 个客户。", "新增 5 个客户")
    chk("新增N个不被误豁免", not r["untraced"], str(r["untraced"]))

    # 段号也是结构：交付模板给表达单元编号，材料里数字少时它会变成满屏噪音
    r = audit("## 第 1 段｜开场\n达成 112%。", "达成率 112%")
    chk("第N段段号豁免", not r["untraced"], str(r["untraced"]))
    r = audit("第 3 段讲的是新增 5 个客户。", "要点清单")
    chk("段号豁免不误伤真数据", [k for k, _ in r["untraced"]] == ["5 个"], str(r["untraced"]))

    # 加粗编号列表：追问预备就是这么写的，不豁免会人人多出几条噪音
    r = audit("**1. 听众会问：** 会不会砍服务？\n**2. 听众会问：** 目标怎么定的？", "要点清单")
    chk("加粗编号列表豁免", not r["untraced"], str(r["untraced"]))
    # 材料写「一个」、讲稿写「1 个」是同一件事，不该报
    r = audit("申请 1 个正式编制。", "需要一个正式编制来牵头")
    chk("中文数字与阿拉伯数字互通", not r["untraced"], str(r["untraced"]))
    r = audit("申请 2 个正式编制。", "需要一个正式编制来牵头")
    chk("数量真的不同仍会报", [k for k, _ in r["untraced"]] == ["2 个"], str(r["untraced"]))

    # 13. 段标题里的字数预算不是数据（SKILL.md 模板自带，不豁免会人人中招）
    r = audit("## 开场（约 130 字 / 32 秒）\n达成 112%。", "达成率 112%")
    chk("字数预算不参与核对", not r["untraced"], str(r["untraced"]))

    # 14. 漏检防线：编个「100%」，材料里只有一个裸「1」不能把它放行
    r = audit("目标是增长 100%。", "团队 6 人（3 开发、2 算法、1 产品）")
    chk("裸整数不能放行百分比", [k for k, _ in r["untraced"]] == ["100%"], str(r["untraced"]))
    r = audit("目标是增长 100%。", "目标增长 100%")
    chk("材料真有 100% 时不误报", not r["untraced"], str(r["untraced"]))
    # 但正常的百分比 <-> 倍率互通不能被改废
    r = audit("达成 112%。", "达成率 1.12 倍")
    chk("百分比与倍数仍互通", not r["untraced"], str(r["untraced"]))

    # 15. 以 p 结尾的词不能被当成页码：「Top 200」不是 P200
    r = audit("覆盖了 200 个问题。", "把 Top 200 高频问题做成快答通道")
    chk("Top 200 不被当成页码", not r["untraced"], str(r["untraced"]))
    r = audit("第 3 页和 P5 上写着 200 个。", "高频问题 200 个")
    chk("真页码仍被豁免", [k for k, _ in r["untraced"]] == [], str(r["untraced"]))
    # 表格之后的正文不能被吞（RE_TABLE_SEP 曾用 \s 跨行吃到后面）
    r = audit("成本 0.35 元。", "| 指标 | 一期 |\n|---|---|\n| 成本 | 0.77 元 |\n\nQ4 目标 0.35 元。")
    chk("表格后的数字仍能溯源", not r["untraced"], str(r["untraced"]))

    # 16. 数字 token 不吃尾随逗号；逗号两侧都是数字时不能合成一个数
    toks, _ = extract("峰值 QPS 8600，其中写 QPS 3100")
    chk("尾随逗号不进 token", toks == ["8600", "3100"], str(toks))
    toks, _ = extract("点位 18，31 号")
    chk("逗号两侧数字不合成", toks[:2] == ["18", "31"], str(toks))
    toks, _ = extract("共 1,234 单")
    chk("千分位仍算一个数", toks and toks[0].startswith("1,234"), str(toks))

    # 17. .docx / .pptx 直读：真实用户手里是 deck，不是 md
    try:
        import shutil
        import tempfile
        SLIDE = ('<?xml version="1.0"?>'
                 '<p:sld xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"'
                 ' xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main">'
                 '<p:cSld><p:spTree><p:sp><p:txBody>'
                 '<a:p><a:r><a:t>Q3 </a:t></a:r><a:r><a:t>\u8fbe\u6210 112%</a:t></a:r></a:p>'
                 '<a:p><a:r><a:t>\u65b0\u589e 4.2 \u4e07</a:t></a:r></a:p>'
                 '</p:txBody></p:sp></p:spTree></p:cSld></p:sld>')
        CHART = ('<?xml version="1.0"?>'
                 '<c:chartSpace xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart">'
                 '<c:numCache><c:pt><c:v>1.8</c:v></c:pt><c:pt><c:v>4.2</c:v></c:pt>'
                 '</c:numCache></c:chartSpace>')
        DOC = ('<?xml version="1.0"?>'
               '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
               '<w:body><w:p><w:r><w:t>\u8fbe\u6210\u7387 112%</w:t></w:r></w:p></w:body></w:document>')
        td = tempfile.mkdtemp()
        px = os.path.join(td, "t.pptx")
        with zipfile.ZipFile(px, "w") as z:
            z.writestr("ppt/slides/slide1.xml", SLIDE)
            z.writestr("ppt/slides/charts/chart1.xml", CHART)
        ptxt = read_any(px)
        # run 被拆成两个 <a:t>，必须按段落拼回来
        chk("pptx 按段落拼 run", "Q3 \u8fbe\u6210 112%" in ptxt, repr(ptxt[:40]))
        chk("pptx 图表数值也取到", "1.8" in ptxt and "4.2" in ptxt, repr(ptxt[-24:]))
        r = audit("\u8fbe\u6210 112%\uff0c\u65b0\u589e 4.2 \u4e07\uff0c\u8f6c\u5316 1.8 \u500d\u3002", ptxt)
        chk("pptx 当材料可溯源", not r["untraced"], str(r["untraced"]))
        dx = os.path.join(td, "t.docx")
        with zipfile.ZipFile(dx, "w") as z:
            z.writestr("word/document.xml", DOC)
        chk("docx 直读", "112%" in read_any(dx), repr(read_any(dx)[:20]))
        shutil.rmtree(td, ignore_errors=True)
    except Exception as e:                       # pragma: no cover
        chk("docx / pptx 直读", False, str(e))

    # 12. GBK 文件不能读成乱码（中文 Windows 常见）
    try:
        import tempfile
        fd, tmpp = tempfile.mkstemp(suffix=".md")
        os.close(fd)
        with open(tmpp, "wb") as f:
            f.write("\u8fbe\u6210\u7387 112%".encode("gbk"))
        g = read_text(tmpp)
        chk("GBK 文件按 GB18030 解析",
            "\u8fbe\u6210\u7387" in g and REPL not in g, repr(g[:20]))
        os.remove(tmpp)
    except Exception as e:                       # pragma: no cover
        chk("GBK 文件按 GB18030 解析", False, str(e))

    print("selftest: " + ("OK" if ok else "FAILED"))
    return 0 if ok else 1


def main():
    ap = argparse.ArgumentParser(description="讲稿数字溯源核对")
    ap.add_argument("--script", help="讲稿文件路径")
    ap.add_argument("--source", action="append", default=[],
                    help="原材料文件路径，可重复传多个（PPT 文本、汇报材料、要点清单）")
    ap.add_argument("--script-text", dest="script_text", help="直接传入讲稿文本")
    ap.add_argument("--source-text", dest="source_text", help="直接传入材料文本")
    ap.add_argument("--show-unused", action="store_true",
                    help="额外列出材料里有但讲稿没用到的数字")
    ap.add_argument("--selftest", action="store_true", help="跑内置自检")
    args = ap.parse_args()

    if args.selftest:
        return _selftest()

    def load_one(path):
        if not os.path.exists(path):
            print("找不到文件: %s" % path)
            sys.exit(2)
        if path.lower().endswith(UNREADABLE_EXT):
            print("读不了这种格式：%s" % path)
            print("先把材料导出成 .md / .txt，或另存为 .docx / .pptx —— 这两种脚本能直读。")
            sys.exit(2)
        try:
            return read_any(path)
        except ValueError as exc:
            print("%s\n文件：%s" % (exc, path))
            sys.exit(2)

    if args.script_text:
        st = args.script_text
    elif args.script:
        st = load_one(args.script)
    else:
        print("需要 --script 或 --script-text")
        return 2

    if args.source_text:
        so = args.source_text
    elif args.source:
        so = "\n".join(load_one(p) for p in args.source)
    else:
        print("需要 --source 或 --source-text（材料可以有多个，--source 传多次）")
        return 2

    res = audit(st, so)
    print(render(res, args.show_unused))
    return 1 if res["untraced"] else 0


if __name__ == "__main__":
    sys.exit(main())
