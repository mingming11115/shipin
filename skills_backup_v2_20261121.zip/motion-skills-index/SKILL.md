---
name: motion-skills-index
description: iart.ai 开源的 56 个动效 skill 总索引（19 个主题包：口播 b-roll、动态图表、解说视频、 kinetic typography、WebGL 等），含各子仓库地址与选型建议。触发词：motion-skills、动效包、kinetic typography、数据动画、b-roll、lower thirds。
---

# Motion Skills Index（包装 Skill）

iart-ai/motion-skills（GitHub 2k★）是动效技能的总目录仓库，**56 个 skill 分布在 19 个子仓库**。
本机源码仅含索引与展示：`C:\Users\sunshuting\Desktop\shipin\08_skills_src\motion-skills-master\`

## 19 个主题包速查（按需从 GitHub 安装）

| 包 | 适用 | 数量 | 地址 |
|----|------|------|------|
| explainer-video-skills | 教育解说视频 | 5 | github.com/iart-ai/explainer-video-skills |
| data-animation-skills | 数据图表动画 | 3 | github.com/iart-ai/data-animation-skills |
| youtube-video-skills | 播客/YouTube | 2 | github.com/iart-ai/youtube-video-skills |
| tiktok-video-skills | 竖屏短视频 | 4 | github.com/iart-ai/tiktok-video-skills |
| kinetic-typography-skills | 文字动画 | 1 | github.com/iart-ai/kinetic-typography-skills |
| b-roll-skills | 口播 b-roll | 1 | github.com/iart-ai/b-roll-skills |
| lower-thirds-skills | 字幕条 | 1 | github.com/iart-ai/lower-thirds-skills |
| motion-design-skills | 动效设计 | 9 | github.com/iart-ai/motion-design-skills |
| web-animation-skills | 前端动效 | 9 | github.com/iart-ai/web-animation-skills |
| webgl-animation-skills | 3D/WebGL | 3 | github.com/iart-ai/webgl-animation-skills |
| manim-skills | 数学动画 | 1 | github.com/iart-ai/manim-skills |
| 其余 8 包 | 电商/广告/地图/生成艺术等 | — | 见 README |

## 安装某个包

```bash
curl -sL https://codeload.github.com/iart-ai/<pack>/zip/refs/heads/main -o pack.zip
python -c "import zipfile; zipfile.ZipFile('pack.zip').extractall('.')"
# 把包内各 skill 文件夹拷到 ~/.workbuddy/skills/
```

每个 skill 的共同方法论：**交付-验证循环**（渲染一帧 → 截图 → 自检），
与我们 07_remotion 工程的 `--preview` 关键帧目检流程一致。
