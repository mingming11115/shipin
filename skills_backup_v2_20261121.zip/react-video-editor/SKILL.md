---
name: react-video-editor
description: 基于 Remotion 的开源在线视频编辑器（CapCut/Canva 风格，React + Next.js），可本地运行做拖拽剪辑、模板化批量出片。触发词：react-video-editor、在线视频编辑器、CapCut 克隆、视频编辑 UI。
---

# React Video Editor（包装 Skill）

开源在线视频编辑器（GitHub 1.8k★），Remotion 内核 + Next.js，提供时间轴、
素材库、模板等编辑 UI，适合做"人工微调 + 批量出片"的工作台。

- 本机源码：`C:\Users\sunshuting\Desktop\shipin\08_skills_src\react-video-editor-main\`
- 上游：https://github.com/openvideodev/react-video-editor

## 本地运行

```bash
cd 08_skills_src/react-video-editor-main
npm install        # 或 pnpm install（仓库带 pnpm-lock.yaml）
npm run dev        # Next.js 开发服务器
```

## 与本项目的关系

- 我们的主渲染流水线在 `shipin/07_remotion/`（纯代码渲染，无 UI）
- 需要人工拖拽微调镜头顺序/字幕样式时，可把 Composition 接入此编辑器
