# WorkBuddy Skills 云备份 v2（2026-11-21 20:45）

## 本包内容（除 figgenie 外全部 22 个 skill）
- 13 × remotion-dev/skills 官方技能（remotion-best-practices/captions/create/docs/interactivity/license/maps/markup/multimedia/render/saas/studio/upgrade）
- video-shotcraft（43M，镜头配方，已剔除 demos/gallery）
- anything2explainer（24M，主题→解说视频，含模板）
- rea-video（112K，视频逆向复刻）
- remotion-video-maker / presentation-script（市场安装）
- openmontage-suite / react-video-editor / motion-skills-index（包装 skill，指向本机源码）
- Remotion 工程配置：package.json / tsconfig.json / remotion.config.ts

## 恢复步骤（新电脑）
1. 解压本包，把各 skill 文件夹拷到 C:/Users/<用户名>/.workbuddy/skills/，重启 WorkBuddy
2. Remotion 工程：配置文件放回 shipin/07_remotion/，然后
   npm install --registry=https://registry.npmmirror.com
3. Python：python -m pip install -i https://mirrors.aliyun.com/pypi/simple edge-tts imageio-ffmpeg pymupdf mutagen
4. 未随包内容（公开仓库，从源重装）：
   - figgenie-paper-diagram: github.com/Sleepy-Avacado/FigGenie-paper-diagram-skill
   - OpenMontage 源码(75M): github.com/OpenMontageInc/OpenMontage
   - react-video-editor 源码: github.com/openvideodev/react-video-editor
   - motion-skills 各主题包: github.com/iart-ai/<pack>
