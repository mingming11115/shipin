---
name: openmontage-suite
description: OpenMontage 开源 agentic 视频生产系统的技能套件入口。141 个子技能（TTS/数字人/文生视频/GSAP/Three.js/Manim/Remotion 等）位于本机源码目录，按需查阅加载。触发词：OpenMontage、视频生产管线、数字人、seedance、heygen、threejs 动画。
---

# OpenMontage Suite（包装 Skill）

OpenMontage（GitHub 82k★）是一个完整的 agentic 视频生产系统，**本体不是单技能**，
而是包含 141 个子技能的套件（位于源码 `.agents/skills/`）。

- 本机源码：`C:\Users\sunshuting\Desktop\shipin\08_skills_src\OpenMontage-main\`
- 子技能目录：`08_skills_src\OpenMontage-main\.agents\skills\<name>\SKILL.md`
- 上游：https://github.com/OpenMontageInc/OpenMontage

## 使用方式

需要某个子技能时，直接读取对应 SKILL.md 全文并按其指引执行。重点子技能索引：

| 类别 | 子技能 |
|------|--------|
| Remotion | `remotion` `remotion-best-practices` `remotion-to-hyperframes` |
| 文生视频 API | `seedance-2-5` `kling-official` `pika-h3-flex` `ltx2` `minimax-h3` `grok-media` |
| 语音 | `text-to-speech` `azure-text-to-speech` `elevenlabs` `fish-audio-tts` `doubao-tts` |
| 动效 | `gsap-*`（7 个）`threejs-*`（8 个）`manim-*` `framer-motion` `lottie-bodymovin` `motion-graphics` |
| 合成/工具 | `ffmpeg` `comfyui` `playwright-recording` `canvas-procedural-animation` |

注意：部分子技能依赖 OpenMontage 运行时或第三方 API key，独立使用前先读其 SKILL.md 的前置条件。
